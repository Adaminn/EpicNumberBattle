﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Net;
using System.Net.Sockets;


namespace TpcClient
{
    class Hrac
    {
       
        static Socket s;
        string jmeno;
        string ipAdresa;
        int zlato = 15;
        int platina = 15;
        public Hrac(string jmeno, string ipAdresa)
        {
            this.jmeno = jmeno;
            this.ipAdresa = ipAdresa;


            s = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            s.Connect(IPAddress.Parse(ipAdresa), 6666); // 2

            s.Send(Encoding.Default.GetBytes(this.jmeno + "@" + this.ipAdresa + "@" + this.zlato + "@" + this.platina)); // + meny + koupenz itemy
  
            Thread ziskatdatVlak = new Thread(new ThreadStart(procesZiskavaniDat));
            ziskatdatVlak.Name = "ziskatdatVlak";
            ziskatdatVlak.Start();/*
            Thread posilaniDatVlak = new Thread(delegate () { procesPosilaniDat(this.jmeno); });
            posilaniDatVlak.Name = "posilaniDatVlak";
            posilaniDatVlak.Start();*/
            while (true)
            {
                string text = Console.ReadLine();
                string akce = "";
                for (int i = 0; i < text.Length; i++)
                {
                    if (text[i] != ' ')
                    {
                        akce += text[i];
                    }
                    else
                    {
                        text = text.Remove(0, i + 1);
                        break;
                    }
                }

                if (akce == "send")
                {

                    string komu = "";
                    for (int i = 0; i < text.Length; i++)
                    {
                        if (text[i] != ' ')
                        {
                            komu += text[i];
                        }
                        else
                        {
                            text = text.Remove(0, i + 1);
                            break;
                        }
                    }
                    s.Send(Encoding.Default.GetBytes(akce + "@" + jmeno + "@" + text + "@" + komu));
                }
                else if (akce == "sell")
                {
                    string typ = "";
                    for (int i = 0; i < text.Length; i++)
                    {
                        if (text[i] != ' ')
                        {
                            typ += text[i];
                        }
                        else
                        {
                            text = text.Remove(0, i + 1);
                            break;
                        }
                    }
                    if (typ == "zlato " || typ == "platina")
                    {
                        int kolik;
                        if (int.TryParse(text, out kolik))
                        {
                            if (typ == "zlato")
                            {
                                this.zlato -= kolik;
                            }
                            else
                            {
                                this.platina -= kolik;
                            }
                            s.Send(Encoding.Default.GetBytes(akce + "@" + typ + "@" + kolik.ToString()));
                        }
                        else
                        {
                            Console.WriteLine("V druhem argumentu prikazu sell musi byt cislo");
                        }
                    }else
                    {
                        Console.WriteLine("V prvnim argumentu prikazu musi byt bud zlato nebo platina");
                    }

                }




            }


        }
        public void procesZiskavaniDat() // tohle ti vysvetlime
        {
            byte[] data;
            byte[] adata = null;
            string dat = "";
            while (true)
            {

                data = new byte[s.SendBufferSize]; // 6
                int j = s.Receive(data); // 7
                adata = new byte[j];         // 7
                for (int i = 0; i < j; i++)         // 7
                    adata[i] = data[i];             // 7
                dat = Encoding.Default.GetString(adata); // 8
                //Console.WriteLine(dat);
                string[] zakodovanaZprava = dat.Split('@');
                if (zakodovanaZprava[0] == "send") // zprava
                {

                     Console.WriteLine(zakodovanaZprava[1]+ ": "+ zakodovanaZprava[2]);
               
                    
                }

            }

        }
    
    }
}
