﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using TpcClient;

namespace TpcServer
{
    class Program
    {
        static void Main(string[] args)
        {
            int pocetHracu = int.Parse(Console.ReadLine());
            TcpServer server = new TcpServer(pocetHracu);
        }
    }
}
