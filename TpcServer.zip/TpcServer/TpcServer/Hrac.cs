﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Net;
using System.Net.Sockets;
using TpcServer;

namespace TpcClient
{
    class Hrac
    {
        
        Socket s;
        string jmeno;
        string ipAdresa;
        int zlato;
        int platina;
        bool ukonceniTahu = false;
        public Hrac(string jmeno, string ipAdresa, int zlato, int platina, Socket s)
        {
            this.jmeno = jmeno;
            this.ipAdresa = ipAdresa;
            this.zlato = zlato;
            this.platina = platina;
            this.s = s;


           


        }
        public void setUkonceniTahu(bool ukonecniTahu)
        {
            this.ukonceniTahu = ukonceniTahu;
        }

        public bool getUkonceniTahu()
        {
            return this.ukonceniTahu;
        }
        public string getJmeno()
        {
            return this.jmeno;
        }
        public Socket getSocket()
        {
            return this.s;
        }
        
    }
}
