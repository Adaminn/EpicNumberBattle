﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Net;
using System.Net.Sockets;


namespace TpcClient
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("What is your name?");//nesmi zacinat cislici
            Hrac hrac1 = new Hrac(Console.ReadLine(), "127.0.0.1");
        }
    }
}
