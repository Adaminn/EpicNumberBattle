﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using TpcClient;

namespace TpcServer
{
    class TcpServer
    {
                                            // spust tolik klientu kolik jsi napsasl ze bude hrat hracu, napis jmena, a posli spravu ve fromatu: send (jmeno toho hrace) (tvoje zprava)
        Socket socket;
        byte[] data = null;
        Hrac[] hraci;
        int pocetHracu;
        private static int[,] stul = new int[3, 2];


        public TcpServer(int pocetHracu)
        {
            this.pocetHracu = pocetHracu;
            hraci = new Hrac[pocetHracu];
            Thread[] poslouchajiciVlakna = new Thread[pocetHracu];
            Thread.CurrentThread.Name = "hlavni";
            socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp); // 2   // tyto cisla ignoruj
            socket.Bind(new IPEndPoint(IPAddress.Any, 6666)); // 3
            socket.Listen(pocetHracu); // 4
            for (int id = 0; id < pocetHracu; id++)  // cekani na vsechny hrace a zapisovani informaci o nich
            {       // tohle ti vysvetlime
                Socket pom = socket.Accept();

                byte[] adata = null;
                string dat = "";
                data = new byte[pom.SendBufferSize]; // 6
                int j = pom.Receive(data); // 7
                adata = new byte[j];         // 7
                for (int i = 0; i < j; i++)         // 7
                    adata[i] = data[i];             // 7
                dat = Encoding.Default.GetString(adata); // 8
                Console.WriteLine(dat);
                string[] vlastnostiHrace = dat.Split('@');

                hraci[id] = new Hrac(vlastnostiHrace[0], vlastnostiHrace[1], int.Parse(vlastnostiHrace[2]), int.Parse(vlastnostiHrace[3]), pom);

                
            }
            //hraci.Add(); // 5
            for (int i = 0; i < pocetHracu; i++) // pro kazdyho hrace jedno vlakno!
            {
                Console.WriteLine("i" + i);
                poslouchajiciVlakna[i] = new Thread((delegate () { ziskavaniDat(i); }));
                poslouchajiciVlakna[i].Name = "ziskatdatVlak" +  i;
                poslouchajiciVlakna[i].Start();
                Thread.Sleep(100);
            }
     

        }




        public void ziskavaniDat(int id)  // neni to ziskavani dat, jen se kontroluje jestli mu nekdo vubec neco poslal
        {
            Console.WriteLine("hmm");
            Console.WriteLine(id);
        
            data = new byte[hraci[id].getSocket().SendBufferSize]; // 6
            Console.WriteLine("aaa");

            zpracovaniDat(id, data);

        }
        public void zpracovaniDat(int id, byte[] data)  // tohle je ziskavani dat + zpracovavani dat
        {

            Console.WriteLine("funcke");
            byte[] adata = null;
            string dat = "";
            while (true)       // tohle ti vysvetlime
            {

                int j = hraci[id].getSocket().Receive(data); // 7
                adata = new byte[j];         // 7
                for (int i = 0; i < j; i++)         // 7
                    adata[i] = data[i];             // 7
                dat = Encoding.Default.GetString(adata); // 8
                Console.WriteLine(dat);
                string[] zakodovanaZprava = dat.Split('@');
                if (zakodovanaZprava[0] == "send") // zprava
                {
                    Console.WriteLine("zpravppppa");
                    for (int i = 0; i < pocetHracu; i++)
                    {
                        Console.WriteLine("toSnadJoNe");
                        Console.WriteLine(hraci[i].getJmeno());
                        Console.WriteLine(zakodovanaZprava[3]);
                        if (hraci[i].getJmeno() == zakodovanaZprava[3])
                        {
                            Console.WriteLine("zprava");
                            hraci[i].getSocket().Send(Encoding.Default.GetBytes(string.Join("@", zakodovanaZprava)));
                        }
                    }
                }/*
                else if (zakodovanaZprava[0] == "sell")
                {
                    int[,] stul = new int[3, 2];

                    if (zakodovanaZprava[1] == "zlato")
                    {
                        //ulozi aktualni sazku hrace

                        stul[id, 0] = int.Parse(zakodovanaZprava[2]); //mnozstvi
                        stul[id, 1] = 0; //typ mince
                    }
                    else if (zakodovanaZprava[1] == "platina")
                    {
                        //ulozi aktualni sazku hrace

                        stul[id, 0] = int.Parse(zakodovanaZprava[2]); //mnozstvi
                        stul[id, 1] = 1; //typ mince
                    }
                    hraci[id].setUkonceniTahu(true);
                    int znicit = 0;
                    while (true)
                    {
                        if (znicit == 3) // 3 hraci  // zacina royhodovani o win coin
                        {
                            int nejZ = 0;
                            int nejP = 0;
                            for (int i = 0; i < 3; i++)
                            {
                                if (stul[i, 1] == 0)
                                {
                                    if (stul[i, 0] > nejZ)
                                    {

                                    }
                                }
                            }
                            break;
                        }
                        if (hraci[znicit].getUkonceniTahu() == false)
                        {
                            break;
                        }
                        znicit++;
                    }

               
                }
                */
            }

        }
        /*
        public static void procesPosilaniDat()
        {
            while (true)
            {
                accepteddata.Send(Encoding.Default.GetBytes(Console.ReadLine()));
            }
        }
        */
    }
}
